#include <stdio.h>
// #include <omp.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#define N 20 //using 20 a maximum as file only goes to 13 max

FILE *fp;
char *file = "./1811952-matrices.txt";
int currentLine = 0;
char delim[] = ",";
int i = 0;
int j = 0;

float (*get_Matrix_One(void))[N]
{
    char *split;
    char line[256];
    float(*matrix)[20] = malloc(1000 * sizeof(float));
    char *value;
    fp = fopen(file, "r");

    while ((fgets(line, sizeof(line), fp)))
    {
        if (*line == '\n')
        {
            currentLine++;
            break;
        }
        currentLine++;
        split = strtok(line, ","); //splits the string by comma
        while (split != NULL) // iterates over the split 
        {
            if (currentLine == 1) //skips size of matrix line
            {
                break;
            }
            else
            {
                // printf("currentLine: %d\n", currentLine);
                // printf("i: %d\n", i);
                matrix[currentLine][i] = atoi(split); //sets matrix position to int of split token
                // printf("%f\n", matrix[currentLine][i]);
                i++;
                split = strtok(NULL, ",");
            }
        }
    }
    fclose(fp);
    return matrix;
}
// get matrix two
float (*get_Matrix_Two(void))[N]
{
    char *split;
    char *value;
    char line[256];
    float(*matrix2)[20] = malloc(1000 * sizeof(float));
    fp = fopen(file, "r");
    bool check = false;
    int counter = 0;
    int currentLine2 = 0;
    while ((fgets(line, sizeof(line), fp)))
    {
        if (counter != currentLine) //counts up to previous line
        {
            // printf("counter ---- %d\n", counter);
            // printf("previous line ------ %d\n", currentLine);
            counter++;
        }
        else
        {
            check = true;
        }
        if (check)
        {
            if (*line == '\n') //skips the first line which has the size of matrix
            {
                currentLine2++;
                break;
            }
            currentLine2++;
            split = strtok(line, ","); 
            while (split != NULL)
                if (currentLine2 == 1)
                {
                    break;
                }
                else
                {
                    {
                        // printf("currentLine2: %d\n", currentLine2);
                        // printf("j: %d\n", j);
                        matrix2[currentLine2][j] = atoi(split);
                        // printf("%f\n", matrix2[currentLine2][j]);
                        j++;
                        split = strtok(NULL, ",");
                    }
                }
        }
    }
    fclose(fp);
    //printf("***************************************\n"); //QOL for debug
    return matrix2;
}

void multiplyMatrices(float matrix1[][N], float matrix2[][N], int result[][N])
{
    int i, j, k;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            result[i][j] = 0;
            for (k = 0; k < N; k++)
                result[i][j] += matrix1[i][k] * matrix2[k][j];
        }
    }
}
int main(void)
{
    int result[20][20]; //used int for greater readability
    multiplyMatrices(get_Matrix_One(), get_Matrix_Two(), result);
    
    //reading/displaying result
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
            printf("%d ", result[i][j]);
        printf("\n");
    }
    return 0;

}

/********************************************************unused code which may have use ******************************************************/
    // get_Matrix_One(matrix);
    // printf("*************");
    // get_Matrix_Two(matrix2);
    // float elements = sizeof(matrix)/sizeof(*matrix);
    // for (i = 0; i < N; i++)

    // for (int i = 0; i < M; i++)
    // {
        // for (int j = 0; j < N; j++)
        // {
            // A[i][j] = i + j + 1;
            // B[j][i] = (i + 1) * (j + 1);
        // }
    // }
// 
    // for (int i = 0; i < M; i++)
    // {
        // for (int j = 0; j < M; j++)
        // {
            // C[i][j] = 0.0;
            // for (int k = 0; k < N; k++)
            // {
                // C[i][j] += A[i][k] * B[k][j];
            // }
        // }
    // }
// 
    // for (int i = 0; i < M; i++)
    // {
        // for (int j = 0; j < M; j++)
        // {
            // printf("%lf\t", C[i][j]);
        // }
        // printf("\n");
    // }
