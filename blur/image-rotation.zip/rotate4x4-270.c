#include <stdio.h>

int a[4][4] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
int b[4][4];

void main()
{
  for(int i = 0; i < 4; i++){
    for(int j = 0; j < 4; j++){
      printf("[%2d] ", a[i][j]);
      b[i][j] = a[j][4 - i - 1];
    }
    printf("\n");
  }
  printf("Rotate 270 deg\n");

  for(int i = 0; i < 4; i++){
    for(int j = 0; j < 4; j++){
      printf("[%2d] ", b[i][j]);
    }
    printf("\n");
  }
}
